#include "CStack.h"
#include <stdio.h>

void CStack::push() //��� �Լ� => �޼���
{
	printf("stack�� ���� ���� �Է����ּ���: ");
	int value;
	scanf("%d", &value);
	if (top > MAX_STACK) {
		printf("Stack Overflow! (�� �̻� push �Ұ�)\n");
	}
	stack_buff[top++] = value;
}

int CStack::pop()
{
	if (top <= 0) {
		printf("Stack Underflow! (Stack �� �����ϴ�)\n");
		return -1;
	}
	return stack_buff[--top];
}

void CStack::print_stack()
{
	printf("\n<stack ����>\n");
	for (int i = 0; i < top; i++) {
		printf(" | %d", stack_buff[i]);
	}
	printf("\n\n");
}

int CStack::load_stack()
{
	FILE* StackFile = fopen("save_stack.txt", "r");
	if (!StackFile) {
		printf("[���� ����]\n");
		return 0;
	}
	fscanf(StackFile, "%d", &top);
	if (top < 0) top = 0;
	if (top > MAX_STACK) top = MAX_STACK;

	for (int i = 0; i < top; i++) {
		fscanf(StackFile, "%d", &stack_buff[i]);
	}
	fclose(StackFile);
	return 1;
}

int CStack::save_stack()
{
	FILE* StackFile = fopen("save_stack.txt", "w");
	if (!StackFile) {
		printf("[���� ����]\n");
		return 0;
	}
	fprintf(StackFile, "%d\n", top);
	for (int i = 0; i < top; i++) {
		fprintf(StackFile, "%d ", stack_buff[i]);
	}
	fprintf(StackFile, "\n");
	fclose(StackFile);
	return 1;
}